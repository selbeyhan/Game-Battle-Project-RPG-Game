#include <iostream>
#include "InputValidation.h"
#include "Game.h"
using namespace std;

// system("cls");

int main()
{
    Game game;
    return 0;
}